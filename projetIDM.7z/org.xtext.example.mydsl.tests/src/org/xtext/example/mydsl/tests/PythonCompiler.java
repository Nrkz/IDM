package org.xtext.example.mydsl.tests;

import org.xtext.example.mydsl.myCsv.AddLine;
import org.xtext.example.mydsl.myCsv.CSV;
import org.xtext.example.mydsl.myCsv.Methode;
import org.xtext.example.mydsl.myCsv.Model;
import org.xtext.example.mydsl.myCsv.PrintCSV;
import org.xtext.example.mydsl.myCsv.ReadLine;
import org.xtext.example.mydsl.myCsv.StringParser;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

import com.google.common.io.Files;

public class PythonCompiler {

	private Model _model;

	PythonCompiler(Model model) {	
		_model = model;	
	}
	
	public void compileAndRun() throws IOException {
	
		// code generation
		String pythonCode = "import csv \r\n";
		for(CSV csv : _model.getCsv()) {
			String csvFilename = csv.getPath();
			for(Methode methode : csv.getMethode()) {
				if(methode instanceof AddLine) {
					AddLine addLine = (AddLine) methode;
					pythonCode += "def addline(line):\r\n"
							+ "    with open(\"" + csvFilename +"\", 'a', newline='', encoding='utf-8') as csvFile:\r\n"
							+ "        _writer = csv.writer(csvFile)\r\n"
							+ "        _writer.writerow([line])\r\n"
							+ "\r\n"
							+ "addline(\"blbl\")\r\n"
							+ "addline(\'"+addLine.getLine().replace("\"", "")+"\')";
				} else if (methode instanceof ReadLine) {
					ReadLine read =(ReadLine) methode;
					pythonCode += "def readline(line):\r\n"
							+ "    with open(\"" + csvFilename +"\", 'r', newline='', encoding='utf-8') as csvFile:\r\n"
							+ "        _reader = csv.reader(csvFile)\r\n"
							+ "        try:\r\n"
							+ "            for row in _reader:\r\n"
							+ "                if _reader.line_num == line:\r\n"
							+ "                    str = \"\"\r\n"
							+ "                    for char in row:\r\n"
							+ "                        str += char\r\n"
							+ "                    return str\r\n"
							+ "\r\n"
							+ "        except csv.Error as e:\r\n"
							+ "            sys.exit('file {}, line {}: {}'.format(filename, reader.line_num, e))"
							+ "\r\n"
							+ "readline("+read.getLine()+")\r\n";
				} else if (methode instanceof StringParser) {
					StringParser parser = (StringParser) methode;
					pythonCode += "def stringparser(str):\r\n"
							+ "    with open(\"" + csvFilename + "\", 'w', newline='', encoding='utf-8') as csvfile:\r\n"
							+ "        _writer = csv.writer(csvfile)\r\n"
							+ "        lines = str.split(\"\\r\")\r\n"
							+ "        for line in lines:\r\n"
							+ "            print(line)\r\n"
							+ "            _writer.writerow([line])"
							+ "\r\n"
							+ "stringparser(\"" + parser.getText() + "\")";
				} else if (methode instanceof PrintCSV) {
					PrintCSV print = (PrintCSV) methode;
					pythonCode +="def printCSV():\r\n"
							+ "    res=\"\"\r\n"
							+ "    with open(\""+ csvFilename + "\", 'r', newline='', encoding='utf-8') as csvFile:\r\n"
							+ "        _reader = csv.reader(csvFile)\r\n"
							+ "        for line in _reader:\r\n"
							+ "            res+=line[0]+\"\\n\"\r\n"
							+ "        print(res)"
							+ "\r\n"
							+ "printCSV()";
				}
			}
		}
		// serialize code into Python filename
		String PYTHON_OUTPUT = "pythonCompiler.py";			
		/*
		FileWriter fw = new FileWriter(PYTHON_OUTPUT);
		fw.write(pythonCode);
		fw.flush();
		fw.close();	
		*/
		// or shorter
		Files.write(pythonCode.getBytes(), new File(PYTHON_OUTPUT));
		
		// execute the generated Python code
		// roughly: exec "python foo.py"
		
		Process p = Runtime.getRuntime().exec("python " + PYTHON_OUTPUT);
	    
		// output
	    BufferedReader stdInput = new BufferedReader(new 
	         InputStreamReader(p.getInputStream()));
	
	    // error
	    BufferedReader stdError = new BufferedReader(new 
	         InputStreamReader(p.getErrorStream()));
	
	    String o;
		while ((o = stdInput.readLine()) != null) {
	        System.out.println(o);
	    }
	    
		String err; 
		while ((err = stdError.readLine()) != null) {
	        System.out.println(err);
	    }
	}
	
}
