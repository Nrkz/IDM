package org.xtext.example.mydsl.tests;


import org.xtext.example.mydsl.myCsv.AddLine;
import org.xtext.example.mydsl.myCsv.CSV;
import org.xtext.example.mydsl.myCsv.Methode;
import org.xtext.example.mydsl.myCsv.Model;
import org.xtext.example.mydsl.myCsv.PrintCSV;
import org.xtext.example.mydsl.myCsv.ReadLine;
import org.xtext.example.mydsl.myCsv.StringParser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;

import com.google.common.io.Files;

public class CommonsCompiler {

	private Model _model;

	CommonsCompiler(Model model) {	
		_model = model;	
	}
	
	public void compileAndRun() throws IOException {
	
		// code generation
		String commonsCode = "package org.xtext.example.mydsl.tests;\r\n"
				+ "import java.io.File; \r\n"
				+ "import java.io.BufferedReader;\r\n"
				+ "import java.io.FileReader;\r\n"
				+ "import java.io.FileWriter; \r\n"
				+ "import java.io.IOException; \r\n"
				+ "import java.nio.file.Paths; \r\n"
				+ "import java.util.Map;\r\n"
				+ "import org.apache.commons.csv.CSVFormat;\r\n"
				+ "import org.apache.commons.csv.CSVPrinter;\r\n"
				+ "public class CommonsCode { \r\n"
				+ "public static void main( String[] args ) throws IOException { ";
		for(CSV csv : _model.getCsv()) {
			String csvFilename = csv.getPath();
			for(Methode methode : csv.getMethode()) {
				if(methode instanceof AddLine) {
					AddLine addLine = (AddLine) methode;
					commonsCode += "try (CSVPrinter printer = new CSVPrinter(new FileWriter(\""+csvFilename+"\",true), CSVFormat.DEFAULT)) {\r\n"
							+ "	     printer.printRecord(\""+addLine.getLine()+"\");\r\n"
							+ "	 } catch (IOException ex) {\r\n"
							+ "	     ex.printStackTrace();\r\n"
							+ "	 }";
				} else if (methode instanceof ReadLine) {
					ReadLine read =(ReadLine) methode;
					commonsCode += "BufferedReader csvReader = new BufferedReader(new FileReader(\""+csvFilename+"\"));\r\n"
							+ "	String row = new String();\r\n"
							+ "	String line = new String();\r\n"
							+ "	int i = 0;\r\n"
							+ "	while ((row = csvReader.readLine()) != null) {\r\n"
							+ "		if(i=="+read.getLine()+") {\r\n"
							+ "	    System.out.println(row);	    \r\n"
							+ "		}\r\n"
							+ "	    i++;\r\n"
							+ "	}\r\n"
							+ "	csvReader.close();";
				} else if (methode instanceof StringParser) {
					StringParser parser = (StringParser) methode;
					commonsCode += "String texte = new String();\r\n"
							+ "	texte = \""+parser.getText()+"\";\r\n"
							+ "	String[] line = texte.split(\"\\r\");\r\n"
							+ "	try (CSVPrinter printer = new CSVPrinter(new FileWriter(\""+csvFilename+"\"), CSVFormat.DEFAULT)) {\r\n"
							+ "		for(int i =0; i<line.length;i++) {\r\n"
							+ "			String res = new String();\r\n"
							+ "			printer.printRecord(line[i]);\r\n"
							+ "		}\r\n"
							+ "	} catch (IOException ex) { \r\n"
							+ "		ex.printStackTrace();\r\n"
							+ "	}";
				} else if (methode instanceof PrintCSV) {
					PrintCSV print = (PrintCSV) methode;
					commonsCode +="String texte = new String();\r\n"
							+ "	BufferedReader csvReader = new BufferedReader(new FileReader(\""+csv.getPath()+"\"));\r\n"
							+ "	String row = new String();\r\n"
							+ "	while ((row = csvReader.readLine()) != null) {\r\n"
							+ "		texte+=row+\"\\r\";  \r\n"
							+ "	}\r\n"
							+ "	System.out.println(texte);";
				}
			}
			commonsCode += "}}";	
		}
		// serialize code into Java filename
	
		String COMMONS_OUTPUT = "CommonsCode.java";			
		/*
		FileWriter fw = new FileWriter(PYTHON_OUTPUT);
		fw.write(pythonCode);
		fw.flush();
		fw.close();	
		*/
		// or shorter
		Files.write(commonsCode.getBytes(), new File(COMMONS_OUTPUT));
		
		// execute the generated Java code
		
		Process p = Runtime.getRuntime().exec("java -cp \"commons-csv-1.8.jar\" "+COMMONS_OUTPUT);
	    
		// output
	    BufferedReader stdInput = new BufferedReader(new 
	         InputStreamReader(p.getInputStream()));
	
	    // error
	    BufferedReader stdError = new BufferedReader(new 
	         InputStreamReader(p.getErrorStream()));
	
	    String o;
		while ((o = stdInput.readLine()) != null) {
	        System.out.println(o);
	    }
	    
		String err; 
		while ((err = stdError.readLine()) != null) {
	        System.out.println(err);
	    }
	}
	
}
