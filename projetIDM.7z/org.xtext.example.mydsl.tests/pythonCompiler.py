import csv 
def addline(line):
    with open("csv1Pyth.csv", 'a', newline='', encoding='utf-8') as csvFile:
        _writer = csv.writer(csvFile)
        _writer.writerow([line])

addline("blbl")
addline('line,line,line')