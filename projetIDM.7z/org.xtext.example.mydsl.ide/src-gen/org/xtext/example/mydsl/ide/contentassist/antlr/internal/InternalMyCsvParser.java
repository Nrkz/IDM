package org.xtext.example.mydsl.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.example.mydsl.services.MyCsvGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyCsvParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_INT", "RULE_ID", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'import'", "'{'", "'}'", "'parseString('", "');'", "'printCSV();'", "'readLine('", "'addLine('"
    };
    public static final int RULE_ID=6;
    public static final int RULE_WS=9;
    public static final int RULE_STRING=4;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int RULE_INT=5;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;

    // delegates
    // delegators


        public InternalMyCsvParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyCsvParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyCsvParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyCsv.g"; }


    	private MyCsvGrammarAccess grammarAccess;

    	public void setGrammarAccess(MyCsvGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleModel"
    // InternalMyCsv.g:53:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // InternalMyCsv.g:54:1: ( ruleModel EOF )
            // InternalMyCsv.g:55:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalMyCsv.g:62:1: ruleModel : ( ( rule__Model__CsvAssignment )* ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:66:2: ( ( ( rule__Model__CsvAssignment )* ) )
            // InternalMyCsv.g:67:2: ( ( rule__Model__CsvAssignment )* )
            {
            // InternalMyCsv.g:67:2: ( ( rule__Model__CsvAssignment )* )
            // InternalMyCsv.g:68:3: ( rule__Model__CsvAssignment )*
            {
             before(grammarAccess.getModelAccess().getCsvAssignment()); 
            // InternalMyCsv.g:69:3: ( rule__Model__CsvAssignment )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalMyCsv.g:69:4: rule__Model__CsvAssignment
            	    {
            	    pushFollow(FOLLOW_3);
            	    rule__Model__CsvAssignment();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getCsvAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleCSV"
    // InternalMyCsv.g:78:1: entryRuleCSV : ruleCSV EOF ;
    public final void entryRuleCSV() throws RecognitionException {
        try {
            // InternalMyCsv.g:79:1: ( ruleCSV EOF )
            // InternalMyCsv.g:80:1: ruleCSV EOF
            {
             before(grammarAccess.getCSVRule()); 
            pushFollow(FOLLOW_1);
            ruleCSV();

            state._fsp--;

             after(grammarAccess.getCSVRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCSV"


    // $ANTLR start "ruleCSV"
    // InternalMyCsv.g:87:1: ruleCSV : ( ( rule__CSV__Group__0 ) ) ;
    public final void ruleCSV() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:91:2: ( ( ( rule__CSV__Group__0 ) ) )
            // InternalMyCsv.g:92:2: ( ( rule__CSV__Group__0 ) )
            {
            // InternalMyCsv.g:92:2: ( ( rule__CSV__Group__0 ) )
            // InternalMyCsv.g:93:3: ( rule__CSV__Group__0 )
            {
             before(grammarAccess.getCSVAccess().getGroup()); 
            // InternalMyCsv.g:94:3: ( rule__CSV__Group__0 )
            // InternalMyCsv.g:94:4: rule__CSV__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__CSV__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCSVAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCSV"


    // $ANTLR start "entryRuleMethode"
    // InternalMyCsv.g:103:1: entryRuleMethode : ruleMethode EOF ;
    public final void entryRuleMethode() throws RecognitionException {
        try {
            // InternalMyCsv.g:104:1: ( ruleMethode EOF )
            // InternalMyCsv.g:105:1: ruleMethode EOF
            {
             before(grammarAccess.getMethodeRule()); 
            pushFollow(FOLLOW_1);
            ruleMethode();

            state._fsp--;

             after(grammarAccess.getMethodeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMethode"


    // $ANTLR start "ruleMethode"
    // InternalMyCsv.g:112:1: ruleMethode : ( ( rule__Methode__Alternatives ) ) ;
    public final void ruleMethode() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:116:2: ( ( ( rule__Methode__Alternatives ) ) )
            // InternalMyCsv.g:117:2: ( ( rule__Methode__Alternatives ) )
            {
            // InternalMyCsv.g:117:2: ( ( rule__Methode__Alternatives ) )
            // InternalMyCsv.g:118:3: ( rule__Methode__Alternatives )
            {
             before(grammarAccess.getMethodeAccess().getAlternatives()); 
            // InternalMyCsv.g:119:3: ( rule__Methode__Alternatives )
            // InternalMyCsv.g:119:4: rule__Methode__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Methode__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getMethodeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMethode"


    // $ANTLR start "entryRuleStringParser"
    // InternalMyCsv.g:128:1: entryRuleStringParser : ruleStringParser EOF ;
    public final void entryRuleStringParser() throws RecognitionException {
        try {
            // InternalMyCsv.g:129:1: ( ruleStringParser EOF )
            // InternalMyCsv.g:130:1: ruleStringParser EOF
            {
             before(grammarAccess.getStringParserRule()); 
            pushFollow(FOLLOW_1);
            ruleStringParser();

            state._fsp--;

             after(grammarAccess.getStringParserRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStringParser"


    // $ANTLR start "ruleStringParser"
    // InternalMyCsv.g:137:1: ruleStringParser : ( ( rule__StringParser__Group__0 ) ) ;
    public final void ruleStringParser() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:141:2: ( ( ( rule__StringParser__Group__0 ) ) )
            // InternalMyCsv.g:142:2: ( ( rule__StringParser__Group__0 ) )
            {
            // InternalMyCsv.g:142:2: ( ( rule__StringParser__Group__0 ) )
            // InternalMyCsv.g:143:3: ( rule__StringParser__Group__0 )
            {
             before(grammarAccess.getStringParserAccess().getGroup()); 
            // InternalMyCsv.g:144:3: ( rule__StringParser__Group__0 )
            // InternalMyCsv.g:144:4: rule__StringParser__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__StringParser__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStringParserAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStringParser"


    // $ANTLR start "entryRulePrintCSV"
    // InternalMyCsv.g:153:1: entryRulePrintCSV : rulePrintCSV EOF ;
    public final void entryRulePrintCSV() throws RecognitionException {
        try {
            // InternalMyCsv.g:154:1: ( rulePrintCSV EOF )
            // InternalMyCsv.g:155:1: rulePrintCSV EOF
            {
             before(grammarAccess.getPrintCSVRule()); 
            pushFollow(FOLLOW_1);
            rulePrintCSV();

            state._fsp--;

             after(grammarAccess.getPrintCSVRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePrintCSV"


    // $ANTLR start "rulePrintCSV"
    // InternalMyCsv.g:162:1: rulePrintCSV : ( ( rule__PrintCSV__Group__0 ) ) ;
    public final void rulePrintCSV() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:166:2: ( ( ( rule__PrintCSV__Group__0 ) ) )
            // InternalMyCsv.g:167:2: ( ( rule__PrintCSV__Group__0 ) )
            {
            // InternalMyCsv.g:167:2: ( ( rule__PrintCSV__Group__0 ) )
            // InternalMyCsv.g:168:3: ( rule__PrintCSV__Group__0 )
            {
             before(grammarAccess.getPrintCSVAccess().getGroup()); 
            // InternalMyCsv.g:169:3: ( rule__PrintCSV__Group__0 )
            // InternalMyCsv.g:169:4: rule__PrintCSV__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__PrintCSV__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPrintCSVAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePrintCSV"


    // $ANTLR start "entryRuleReadLine"
    // InternalMyCsv.g:178:1: entryRuleReadLine : ruleReadLine EOF ;
    public final void entryRuleReadLine() throws RecognitionException {
        try {
            // InternalMyCsv.g:179:1: ( ruleReadLine EOF )
            // InternalMyCsv.g:180:1: ruleReadLine EOF
            {
             before(grammarAccess.getReadLineRule()); 
            pushFollow(FOLLOW_1);
            ruleReadLine();

            state._fsp--;

             after(grammarAccess.getReadLineRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleReadLine"


    // $ANTLR start "ruleReadLine"
    // InternalMyCsv.g:187:1: ruleReadLine : ( ( rule__ReadLine__Group__0 ) ) ;
    public final void ruleReadLine() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:191:2: ( ( ( rule__ReadLine__Group__0 ) ) )
            // InternalMyCsv.g:192:2: ( ( rule__ReadLine__Group__0 ) )
            {
            // InternalMyCsv.g:192:2: ( ( rule__ReadLine__Group__0 ) )
            // InternalMyCsv.g:193:3: ( rule__ReadLine__Group__0 )
            {
             before(grammarAccess.getReadLineAccess().getGroup()); 
            // InternalMyCsv.g:194:3: ( rule__ReadLine__Group__0 )
            // InternalMyCsv.g:194:4: rule__ReadLine__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ReadLine__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getReadLineAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleReadLine"


    // $ANTLR start "entryRuleAddLine"
    // InternalMyCsv.g:203:1: entryRuleAddLine : ruleAddLine EOF ;
    public final void entryRuleAddLine() throws RecognitionException {
        try {
            // InternalMyCsv.g:204:1: ( ruleAddLine EOF )
            // InternalMyCsv.g:205:1: ruleAddLine EOF
            {
             before(grammarAccess.getAddLineRule()); 
            pushFollow(FOLLOW_1);
            ruleAddLine();

            state._fsp--;

             after(grammarAccess.getAddLineRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAddLine"


    // $ANTLR start "ruleAddLine"
    // InternalMyCsv.g:212:1: ruleAddLine : ( ( rule__AddLine__Group__0 ) ) ;
    public final void ruleAddLine() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:216:2: ( ( ( rule__AddLine__Group__0 ) ) )
            // InternalMyCsv.g:217:2: ( ( rule__AddLine__Group__0 ) )
            {
            // InternalMyCsv.g:217:2: ( ( rule__AddLine__Group__0 ) )
            // InternalMyCsv.g:218:3: ( rule__AddLine__Group__0 )
            {
             before(grammarAccess.getAddLineAccess().getGroup()); 
            // InternalMyCsv.g:219:3: ( rule__AddLine__Group__0 )
            // InternalMyCsv.g:219:4: rule__AddLine__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__AddLine__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getAddLineAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAddLine"


    // $ANTLR start "rule__Methode__Alternatives"
    // InternalMyCsv.g:227:1: rule__Methode__Alternatives : ( ( ruleStringParser ) | ( rulePrintCSV ) | ( ruleReadLine ) | ( ruleAddLine ) );
    public final void rule__Methode__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:231:1: ( ( ruleStringParser ) | ( rulePrintCSV ) | ( ruleReadLine ) | ( ruleAddLine ) )
            int alt2=4;
            switch ( input.LA(1) ) {
            case 14:
                {
                alt2=1;
                }
                break;
            case 16:
                {
                alt2=2;
                }
                break;
            case 17:
                {
                alt2=3;
                }
                break;
            case 18:
                {
                alt2=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalMyCsv.g:232:2: ( ruleStringParser )
                    {
                    // InternalMyCsv.g:232:2: ( ruleStringParser )
                    // InternalMyCsv.g:233:3: ruleStringParser
                    {
                     before(grammarAccess.getMethodeAccess().getStringParserParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleStringParser();

                    state._fsp--;

                     after(grammarAccess.getMethodeAccess().getStringParserParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyCsv.g:238:2: ( rulePrintCSV )
                    {
                    // InternalMyCsv.g:238:2: ( rulePrintCSV )
                    // InternalMyCsv.g:239:3: rulePrintCSV
                    {
                     before(grammarAccess.getMethodeAccess().getPrintCSVParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    rulePrintCSV();

                    state._fsp--;

                     after(grammarAccess.getMethodeAccess().getPrintCSVParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyCsv.g:244:2: ( ruleReadLine )
                    {
                    // InternalMyCsv.g:244:2: ( ruleReadLine )
                    // InternalMyCsv.g:245:3: ruleReadLine
                    {
                     before(grammarAccess.getMethodeAccess().getReadLineParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleReadLine();

                    state._fsp--;

                     after(grammarAccess.getMethodeAccess().getReadLineParserRuleCall_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalMyCsv.g:250:2: ( ruleAddLine )
                    {
                    // InternalMyCsv.g:250:2: ( ruleAddLine )
                    // InternalMyCsv.g:251:3: ruleAddLine
                    {
                     before(grammarAccess.getMethodeAccess().getAddLineParserRuleCall_3()); 
                    pushFollow(FOLLOW_2);
                    ruleAddLine();

                    state._fsp--;

                     after(grammarAccess.getMethodeAccess().getAddLineParserRuleCall_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Methode__Alternatives"


    // $ANTLR start "rule__CSV__Group__0"
    // InternalMyCsv.g:260:1: rule__CSV__Group__0 : rule__CSV__Group__0__Impl rule__CSV__Group__1 ;
    public final void rule__CSV__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:264:1: ( rule__CSV__Group__0__Impl rule__CSV__Group__1 )
            // InternalMyCsv.g:265:2: rule__CSV__Group__0__Impl rule__CSV__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__CSV__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CSV__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CSV__Group__0"


    // $ANTLR start "rule__CSV__Group__0__Impl"
    // InternalMyCsv.g:272:1: rule__CSV__Group__0__Impl : ( 'import' ) ;
    public final void rule__CSV__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:276:1: ( ( 'import' ) )
            // InternalMyCsv.g:277:1: ( 'import' )
            {
            // InternalMyCsv.g:277:1: ( 'import' )
            // InternalMyCsv.g:278:2: 'import'
            {
             before(grammarAccess.getCSVAccess().getImportKeyword_0()); 
            match(input,11,FOLLOW_2); 
             after(grammarAccess.getCSVAccess().getImportKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CSV__Group__0__Impl"


    // $ANTLR start "rule__CSV__Group__1"
    // InternalMyCsv.g:287:1: rule__CSV__Group__1 : rule__CSV__Group__1__Impl rule__CSV__Group__2 ;
    public final void rule__CSV__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:291:1: ( rule__CSV__Group__1__Impl rule__CSV__Group__2 )
            // InternalMyCsv.g:292:2: rule__CSV__Group__1__Impl rule__CSV__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__CSV__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CSV__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CSV__Group__1"


    // $ANTLR start "rule__CSV__Group__1__Impl"
    // InternalMyCsv.g:299:1: rule__CSV__Group__1__Impl : ( ( rule__CSV__PathAssignment_1 ) ) ;
    public final void rule__CSV__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:303:1: ( ( ( rule__CSV__PathAssignment_1 ) ) )
            // InternalMyCsv.g:304:1: ( ( rule__CSV__PathAssignment_1 ) )
            {
            // InternalMyCsv.g:304:1: ( ( rule__CSV__PathAssignment_1 ) )
            // InternalMyCsv.g:305:2: ( rule__CSV__PathAssignment_1 )
            {
             before(grammarAccess.getCSVAccess().getPathAssignment_1()); 
            // InternalMyCsv.g:306:2: ( rule__CSV__PathAssignment_1 )
            // InternalMyCsv.g:306:3: rule__CSV__PathAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__CSV__PathAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getCSVAccess().getPathAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CSV__Group__1__Impl"


    // $ANTLR start "rule__CSV__Group__2"
    // InternalMyCsv.g:314:1: rule__CSV__Group__2 : rule__CSV__Group__2__Impl rule__CSV__Group__3 ;
    public final void rule__CSV__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:318:1: ( rule__CSV__Group__2__Impl rule__CSV__Group__3 )
            // InternalMyCsv.g:319:2: rule__CSV__Group__2__Impl rule__CSV__Group__3
            {
            pushFollow(FOLLOW_6);
            rule__CSV__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CSV__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CSV__Group__2"


    // $ANTLR start "rule__CSV__Group__2__Impl"
    // InternalMyCsv.g:326:1: rule__CSV__Group__2__Impl : ( '{' ) ;
    public final void rule__CSV__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:330:1: ( ( '{' ) )
            // InternalMyCsv.g:331:1: ( '{' )
            {
            // InternalMyCsv.g:331:1: ( '{' )
            // InternalMyCsv.g:332:2: '{'
            {
             before(grammarAccess.getCSVAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,12,FOLLOW_2); 
             after(grammarAccess.getCSVAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CSV__Group__2__Impl"


    // $ANTLR start "rule__CSV__Group__3"
    // InternalMyCsv.g:341:1: rule__CSV__Group__3 : rule__CSV__Group__3__Impl rule__CSV__Group__4 ;
    public final void rule__CSV__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:345:1: ( rule__CSV__Group__3__Impl rule__CSV__Group__4 )
            // InternalMyCsv.g:346:2: rule__CSV__Group__3__Impl rule__CSV__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__CSV__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CSV__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CSV__Group__3"


    // $ANTLR start "rule__CSV__Group__3__Impl"
    // InternalMyCsv.g:353:1: rule__CSV__Group__3__Impl : ( ( rule__CSV__MethodeAssignment_3 )* ) ;
    public final void rule__CSV__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:357:1: ( ( ( rule__CSV__MethodeAssignment_3 )* ) )
            // InternalMyCsv.g:358:1: ( ( rule__CSV__MethodeAssignment_3 )* )
            {
            // InternalMyCsv.g:358:1: ( ( rule__CSV__MethodeAssignment_3 )* )
            // InternalMyCsv.g:359:2: ( rule__CSV__MethodeAssignment_3 )*
            {
             before(grammarAccess.getCSVAccess().getMethodeAssignment_3()); 
            // InternalMyCsv.g:360:2: ( rule__CSV__MethodeAssignment_3 )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==14||(LA3_0>=16 && LA3_0<=18)) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalMyCsv.g:360:3: rule__CSV__MethodeAssignment_3
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__CSV__MethodeAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

             after(grammarAccess.getCSVAccess().getMethodeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CSV__Group__3__Impl"


    // $ANTLR start "rule__CSV__Group__4"
    // InternalMyCsv.g:368:1: rule__CSV__Group__4 : rule__CSV__Group__4__Impl ;
    public final void rule__CSV__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:372:1: ( rule__CSV__Group__4__Impl )
            // InternalMyCsv.g:373:2: rule__CSV__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__CSV__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CSV__Group__4"


    // $ANTLR start "rule__CSV__Group__4__Impl"
    // InternalMyCsv.g:379:1: rule__CSV__Group__4__Impl : ( '}' ) ;
    public final void rule__CSV__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:383:1: ( ( '}' ) )
            // InternalMyCsv.g:384:1: ( '}' )
            {
            // InternalMyCsv.g:384:1: ( '}' )
            // InternalMyCsv.g:385:2: '}'
            {
             before(grammarAccess.getCSVAccess().getRightCurlyBracketKeyword_4()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getCSVAccess().getRightCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CSV__Group__4__Impl"


    // $ANTLR start "rule__StringParser__Group__0"
    // InternalMyCsv.g:395:1: rule__StringParser__Group__0 : rule__StringParser__Group__0__Impl rule__StringParser__Group__1 ;
    public final void rule__StringParser__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:399:1: ( rule__StringParser__Group__0__Impl rule__StringParser__Group__1 )
            // InternalMyCsv.g:400:2: rule__StringParser__Group__0__Impl rule__StringParser__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__StringParser__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StringParser__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StringParser__Group__0"


    // $ANTLR start "rule__StringParser__Group__0__Impl"
    // InternalMyCsv.g:407:1: rule__StringParser__Group__0__Impl : ( () ) ;
    public final void rule__StringParser__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:411:1: ( ( () ) )
            // InternalMyCsv.g:412:1: ( () )
            {
            // InternalMyCsv.g:412:1: ( () )
            // InternalMyCsv.g:413:2: ()
            {
             before(grammarAccess.getStringParserAccess().getStringParserAction_0()); 
            // InternalMyCsv.g:414:2: ()
            // InternalMyCsv.g:414:3: 
            {
            }

             after(grammarAccess.getStringParserAccess().getStringParserAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StringParser__Group__0__Impl"


    // $ANTLR start "rule__StringParser__Group__1"
    // InternalMyCsv.g:422:1: rule__StringParser__Group__1 : rule__StringParser__Group__1__Impl rule__StringParser__Group__2 ;
    public final void rule__StringParser__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:426:1: ( rule__StringParser__Group__1__Impl rule__StringParser__Group__2 )
            // InternalMyCsv.g:427:2: rule__StringParser__Group__1__Impl rule__StringParser__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__StringParser__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StringParser__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StringParser__Group__1"


    // $ANTLR start "rule__StringParser__Group__1__Impl"
    // InternalMyCsv.g:434:1: rule__StringParser__Group__1__Impl : ( 'parseString(' ) ;
    public final void rule__StringParser__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:438:1: ( ( 'parseString(' ) )
            // InternalMyCsv.g:439:1: ( 'parseString(' )
            {
            // InternalMyCsv.g:439:1: ( 'parseString(' )
            // InternalMyCsv.g:440:2: 'parseString('
            {
             before(grammarAccess.getStringParserAccess().getParseStringKeyword_1()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getStringParserAccess().getParseStringKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StringParser__Group__1__Impl"


    // $ANTLR start "rule__StringParser__Group__2"
    // InternalMyCsv.g:449:1: rule__StringParser__Group__2 : rule__StringParser__Group__2__Impl rule__StringParser__Group__3 ;
    public final void rule__StringParser__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:453:1: ( rule__StringParser__Group__2__Impl rule__StringParser__Group__3 )
            // InternalMyCsv.g:454:2: rule__StringParser__Group__2__Impl rule__StringParser__Group__3
            {
            pushFollow(FOLLOW_9);
            rule__StringParser__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StringParser__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StringParser__Group__2"


    // $ANTLR start "rule__StringParser__Group__2__Impl"
    // InternalMyCsv.g:461:1: rule__StringParser__Group__2__Impl : ( ( rule__StringParser__TextAssignment_2 ) ) ;
    public final void rule__StringParser__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:465:1: ( ( ( rule__StringParser__TextAssignment_2 ) ) )
            // InternalMyCsv.g:466:1: ( ( rule__StringParser__TextAssignment_2 ) )
            {
            // InternalMyCsv.g:466:1: ( ( rule__StringParser__TextAssignment_2 ) )
            // InternalMyCsv.g:467:2: ( rule__StringParser__TextAssignment_2 )
            {
             before(grammarAccess.getStringParserAccess().getTextAssignment_2()); 
            // InternalMyCsv.g:468:2: ( rule__StringParser__TextAssignment_2 )
            // InternalMyCsv.g:468:3: rule__StringParser__TextAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__StringParser__TextAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getStringParserAccess().getTextAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StringParser__Group__2__Impl"


    // $ANTLR start "rule__StringParser__Group__3"
    // InternalMyCsv.g:476:1: rule__StringParser__Group__3 : rule__StringParser__Group__3__Impl ;
    public final void rule__StringParser__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:480:1: ( rule__StringParser__Group__3__Impl )
            // InternalMyCsv.g:481:2: rule__StringParser__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StringParser__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StringParser__Group__3"


    // $ANTLR start "rule__StringParser__Group__3__Impl"
    // InternalMyCsv.g:487:1: rule__StringParser__Group__3__Impl : ( ');' ) ;
    public final void rule__StringParser__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:491:1: ( ( ');' ) )
            // InternalMyCsv.g:492:1: ( ');' )
            {
            // InternalMyCsv.g:492:1: ( ');' )
            // InternalMyCsv.g:493:2: ');'
            {
             before(grammarAccess.getStringParserAccess().getRightParenthesisSemicolonKeyword_3()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getStringParserAccess().getRightParenthesisSemicolonKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StringParser__Group__3__Impl"


    // $ANTLR start "rule__PrintCSV__Group__0"
    // InternalMyCsv.g:503:1: rule__PrintCSV__Group__0 : rule__PrintCSV__Group__0__Impl rule__PrintCSV__Group__1 ;
    public final void rule__PrintCSV__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:507:1: ( rule__PrintCSV__Group__0__Impl rule__PrintCSV__Group__1 )
            // InternalMyCsv.g:508:2: rule__PrintCSV__Group__0__Impl rule__PrintCSV__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__PrintCSV__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PrintCSV__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrintCSV__Group__0"


    // $ANTLR start "rule__PrintCSV__Group__0__Impl"
    // InternalMyCsv.g:515:1: rule__PrintCSV__Group__0__Impl : ( () ) ;
    public final void rule__PrintCSV__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:519:1: ( ( () ) )
            // InternalMyCsv.g:520:1: ( () )
            {
            // InternalMyCsv.g:520:1: ( () )
            // InternalMyCsv.g:521:2: ()
            {
             before(grammarAccess.getPrintCSVAccess().getPrintAction_0()); 
            // InternalMyCsv.g:522:2: ()
            // InternalMyCsv.g:522:3: 
            {
            }

             after(grammarAccess.getPrintCSVAccess().getPrintAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrintCSV__Group__0__Impl"


    // $ANTLR start "rule__PrintCSV__Group__1"
    // InternalMyCsv.g:530:1: rule__PrintCSV__Group__1 : rule__PrintCSV__Group__1__Impl ;
    public final void rule__PrintCSV__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:534:1: ( rule__PrintCSV__Group__1__Impl )
            // InternalMyCsv.g:535:2: rule__PrintCSV__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__PrintCSV__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrintCSV__Group__1"


    // $ANTLR start "rule__PrintCSV__Group__1__Impl"
    // InternalMyCsv.g:541:1: rule__PrintCSV__Group__1__Impl : ( 'printCSV();' ) ;
    public final void rule__PrintCSV__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:545:1: ( ( 'printCSV();' ) )
            // InternalMyCsv.g:546:1: ( 'printCSV();' )
            {
            // InternalMyCsv.g:546:1: ( 'printCSV();' )
            // InternalMyCsv.g:547:2: 'printCSV();'
            {
             before(grammarAccess.getPrintCSVAccess().getPrintCSVKeyword_1()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getPrintCSVAccess().getPrintCSVKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrintCSV__Group__1__Impl"


    // $ANTLR start "rule__ReadLine__Group__0"
    // InternalMyCsv.g:557:1: rule__ReadLine__Group__0 : rule__ReadLine__Group__0__Impl rule__ReadLine__Group__1 ;
    public final void rule__ReadLine__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:561:1: ( rule__ReadLine__Group__0__Impl rule__ReadLine__Group__1 )
            // InternalMyCsv.g:562:2: rule__ReadLine__Group__0__Impl rule__ReadLine__Group__1
            {
            pushFollow(FOLLOW_11);
            rule__ReadLine__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ReadLine__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ReadLine__Group__0"


    // $ANTLR start "rule__ReadLine__Group__0__Impl"
    // InternalMyCsv.g:569:1: rule__ReadLine__Group__0__Impl : ( 'readLine(' ) ;
    public final void rule__ReadLine__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:573:1: ( ( 'readLine(' ) )
            // InternalMyCsv.g:574:1: ( 'readLine(' )
            {
            // InternalMyCsv.g:574:1: ( 'readLine(' )
            // InternalMyCsv.g:575:2: 'readLine('
            {
             before(grammarAccess.getReadLineAccess().getReadLineKeyword_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getReadLineAccess().getReadLineKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ReadLine__Group__0__Impl"


    // $ANTLR start "rule__ReadLine__Group__1"
    // InternalMyCsv.g:584:1: rule__ReadLine__Group__1 : rule__ReadLine__Group__1__Impl rule__ReadLine__Group__2 ;
    public final void rule__ReadLine__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:588:1: ( rule__ReadLine__Group__1__Impl rule__ReadLine__Group__2 )
            // InternalMyCsv.g:589:2: rule__ReadLine__Group__1__Impl rule__ReadLine__Group__2
            {
            pushFollow(FOLLOW_9);
            rule__ReadLine__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ReadLine__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ReadLine__Group__1"


    // $ANTLR start "rule__ReadLine__Group__1__Impl"
    // InternalMyCsv.g:596:1: rule__ReadLine__Group__1__Impl : ( ( rule__ReadLine__LineAssignment_1 ) ) ;
    public final void rule__ReadLine__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:600:1: ( ( ( rule__ReadLine__LineAssignment_1 ) ) )
            // InternalMyCsv.g:601:1: ( ( rule__ReadLine__LineAssignment_1 ) )
            {
            // InternalMyCsv.g:601:1: ( ( rule__ReadLine__LineAssignment_1 ) )
            // InternalMyCsv.g:602:2: ( rule__ReadLine__LineAssignment_1 )
            {
             before(grammarAccess.getReadLineAccess().getLineAssignment_1()); 
            // InternalMyCsv.g:603:2: ( rule__ReadLine__LineAssignment_1 )
            // InternalMyCsv.g:603:3: rule__ReadLine__LineAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ReadLine__LineAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getReadLineAccess().getLineAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ReadLine__Group__1__Impl"


    // $ANTLR start "rule__ReadLine__Group__2"
    // InternalMyCsv.g:611:1: rule__ReadLine__Group__2 : rule__ReadLine__Group__2__Impl ;
    public final void rule__ReadLine__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:615:1: ( rule__ReadLine__Group__2__Impl )
            // InternalMyCsv.g:616:2: rule__ReadLine__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ReadLine__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ReadLine__Group__2"


    // $ANTLR start "rule__ReadLine__Group__2__Impl"
    // InternalMyCsv.g:622:1: rule__ReadLine__Group__2__Impl : ( ');' ) ;
    public final void rule__ReadLine__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:626:1: ( ( ');' ) )
            // InternalMyCsv.g:627:1: ( ');' )
            {
            // InternalMyCsv.g:627:1: ( ');' )
            // InternalMyCsv.g:628:2: ');'
            {
             before(grammarAccess.getReadLineAccess().getRightParenthesisSemicolonKeyword_2()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getReadLineAccess().getRightParenthesisSemicolonKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ReadLine__Group__2__Impl"


    // $ANTLR start "rule__AddLine__Group__0"
    // InternalMyCsv.g:638:1: rule__AddLine__Group__0 : rule__AddLine__Group__0__Impl rule__AddLine__Group__1 ;
    public final void rule__AddLine__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:642:1: ( rule__AddLine__Group__0__Impl rule__AddLine__Group__1 )
            // InternalMyCsv.g:643:2: rule__AddLine__Group__0__Impl rule__AddLine__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__AddLine__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__AddLine__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AddLine__Group__0"


    // $ANTLR start "rule__AddLine__Group__0__Impl"
    // InternalMyCsv.g:650:1: rule__AddLine__Group__0__Impl : ( 'addLine(' ) ;
    public final void rule__AddLine__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:654:1: ( ( 'addLine(' ) )
            // InternalMyCsv.g:655:1: ( 'addLine(' )
            {
            // InternalMyCsv.g:655:1: ( 'addLine(' )
            // InternalMyCsv.g:656:2: 'addLine('
            {
             before(grammarAccess.getAddLineAccess().getAddLineKeyword_0()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getAddLineAccess().getAddLineKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AddLine__Group__0__Impl"


    // $ANTLR start "rule__AddLine__Group__1"
    // InternalMyCsv.g:665:1: rule__AddLine__Group__1 : rule__AddLine__Group__1__Impl rule__AddLine__Group__2 ;
    public final void rule__AddLine__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:669:1: ( rule__AddLine__Group__1__Impl rule__AddLine__Group__2 )
            // InternalMyCsv.g:670:2: rule__AddLine__Group__1__Impl rule__AddLine__Group__2
            {
            pushFollow(FOLLOW_9);
            rule__AddLine__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__AddLine__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AddLine__Group__1"


    // $ANTLR start "rule__AddLine__Group__1__Impl"
    // InternalMyCsv.g:677:1: rule__AddLine__Group__1__Impl : ( ( rule__AddLine__LineAssignment_1 ) ) ;
    public final void rule__AddLine__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:681:1: ( ( ( rule__AddLine__LineAssignment_1 ) ) )
            // InternalMyCsv.g:682:1: ( ( rule__AddLine__LineAssignment_1 ) )
            {
            // InternalMyCsv.g:682:1: ( ( rule__AddLine__LineAssignment_1 ) )
            // InternalMyCsv.g:683:2: ( rule__AddLine__LineAssignment_1 )
            {
             before(grammarAccess.getAddLineAccess().getLineAssignment_1()); 
            // InternalMyCsv.g:684:2: ( rule__AddLine__LineAssignment_1 )
            // InternalMyCsv.g:684:3: rule__AddLine__LineAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__AddLine__LineAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getAddLineAccess().getLineAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AddLine__Group__1__Impl"


    // $ANTLR start "rule__AddLine__Group__2"
    // InternalMyCsv.g:692:1: rule__AddLine__Group__2 : rule__AddLine__Group__2__Impl ;
    public final void rule__AddLine__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:696:1: ( rule__AddLine__Group__2__Impl )
            // InternalMyCsv.g:697:2: rule__AddLine__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__AddLine__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AddLine__Group__2"


    // $ANTLR start "rule__AddLine__Group__2__Impl"
    // InternalMyCsv.g:703:1: rule__AddLine__Group__2__Impl : ( ');' ) ;
    public final void rule__AddLine__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:707:1: ( ( ');' ) )
            // InternalMyCsv.g:708:1: ( ');' )
            {
            // InternalMyCsv.g:708:1: ( ');' )
            // InternalMyCsv.g:709:2: ');'
            {
             before(grammarAccess.getAddLineAccess().getRightParenthesisSemicolonKeyword_2()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getAddLineAccess().getRightParenthesisSemicolonKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AddLine__Group__2__Impl"


    // $ANTLR start "rule__Model__CsvAssignment"
    // InternalMyCsv.g:719:1: rule__Model__CsvAssignment : ( ruleCSV ) ;
    public final void rule__Model__CsvAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:723:1: ( ( ruleCSV ) )
            // InternalMyCsv.g:724:2: ( ruleCSV )
            {
            // InternalMyCsv.g:724:2: ( ruleCSV )
            // InternalMyCsv.g:725:3: ruleCSV
            {
             before(grammarAccess.getModelAccess().getCsvCSVParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleCSV();

            state._fsp--;

             after(grammarAccess.getModelAccess().getCsvCSVParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__CsvAssignment"


    // $ANTLR start "rule__CSV__PathAssignment_1"
    // InternalMyCsv.g:734:1: rule__CSV__PathAssignment_1 : ( RULE_STRING ) ;
    public final void rule__CSV__PathAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:738:1: ( ( RULE_STRING ) )
            // InternalMyCsv.g:739:2: ( RULE_STRING )
            {
            // InternalMyCsv.g:739:2: ( RULE_STRING )
            // InternalMyCsv.g:740:3: RULE_STRING
            {
             before(grammarAccess.getCSVAccess().getPathSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getCSVAccess().getPathSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CSV__PathAssignment_1"


    // $ANTLR start "rule__CSV__MethodeAssignment_3"
    // InternalMyCsv.g:749:1: rule__CSV__MethodeAssignment_3 : ( ruleMethode ) ;
    public final void rule__CSV__MethodeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:753:1: ( ( ruleMethode ) )
            // InternalMyCsv.g:754:2: ( ruleMethode )
            {
            // InternalMyCsv.g:754:2: ( ruleMethode )
            // InternalMyCsv.g:755:3: ruleMethode
            {
             before(grammarAccess.getCSVAccess().getMethodeMethodeParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleMethode();

            state._fsp--;

             after(grammarAccess.getCSVAccess().getMethodeMethodeParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CSV__MethodeAssignment_3"


    // $ANTLR start "rule__StringParser__TextAssignment_2"
    // InternalMyCsv.g:764:1: rule__StringParser__TextAssignment_2 : ( RULE_STRING ) ;
    public final void rule__StringParser__TextAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:768:1: ( ( RULE_STRING ) )
            // InternalMyCsv.g:769:2: ( RULE_STRING )
            {
            // InternalMyCsv.g:769:2: ( RULE_STRING )
            // InternalMyCsv.g:770:3: RULE_STRING
            {
             before(grammarAccess.getStringParserAccess().getTextSTRINGTerminalRuleCall_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getStringParserAccess().getTextSTRINGTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StringParser__TextAssignment_2"


    // $ANTLR start "rule__ReadLine__LineAssignment_1"
    // InternalMyCsv.g:779:1: rule__ReadLine__LineAssignment_1 : ( RULE_INT ) ;
    public final void rule__ReadLine__LineAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:783:1: ( ( RULE_INT ) )
            // InternalMyCsv.g:784:2: ( RULE_INT )
            {
            // InternalMyCsv.g:784:2: ( RULE_INT )
            // InternalMyCsv.g:785:3: RULE_INT
            {
             before(grammarAccess.getReadLineAccess().getLineINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getReadLineAccess().getLineINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ReadLine__LineAssignment_1"


    // $ANTLR start "rule__AddLine__LineAssignment_1"
    // InternalMyCsv.g:794:1: rule__AddLine__LineAssignment_1 : ( RULE_STRING ) ;
    public final void rule__AddLine__LineAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyCsv.g:798:1: ( ( RULE_STRING ) )
            // InternalMyCsv.g:799:2: ( RULE_STRING )
            {
            // InternalMyCsv.g:799:2: ( RULE_STRING )
            // InternalMyCsv.g:800:3: RULE_STRING
            {
             before(grammarAccess.getAddLineAccess().getLineSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getAddLineAccess().getLineSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AddLine__LineAssignment_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000076000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000074002L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000020L});

}