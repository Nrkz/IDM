package org.xtext.example.mydsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.mydsl.services.MyCsvGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyCsvParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_INT", "RULE_ID", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'import'", "'{'", "'}'", "'parseString('", "');'", "'printCSV();'", "'readLine('", "'addLine('"
    };
    public static final int RULE_ID=6;
    public static final int RULE_WS=9;
    public static final int RULE_STRING=4;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int RULE_INT=5;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;

    // delegates
    // delegators


        public InternalMyCsvParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyCsvParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyCsvParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyCsv.g"; }



     	private MyCsvGrammarAccess grammarAccess;

        public InternalMyCsvParser(TokenStream input, MyCsvGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected MyCsvGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalMyCsv.g:64:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalMyCsv.g:64:46: (iv_ruleModel= ruleModel EOF )
            // InternalMyCsv.g:65:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalMyCsv.g:71:1: ruleModel returns [EObject current=null] : ( (lv_csv_0_0= ruleCSV ) )* ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_csv_0_0 = null;



        	enterRule();

        try {
            // InternalMyCsv.g:77:2: ( ( (lv_csv_0_0= ruleCSV ) )* )
            // InternalMyCsv.g:78:2: ( (lv_csv_0_0= ruleCSV ) )*
            {
            // InternalMyCsv.g:78:2: ( (lv_csv_0_0= ruleCSV ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalMyCsv.g:79:3: (lv_csv_0_0= ruleCSV )
            	    {
            	    // InternalMyCsv.g:79:3: (lv_csv_0_0= ruleCSV )
            	    // InternalMyCsv.g:80:4: lv_csv_0_0= ruleCSV
            	    {

            	    				newCompositeNode(grammarAccess.getModelAccess().getCsvCSVParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_3);
            	    lv_csv_0_0=ruleCSV();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getModelRule());
            	    				}
            	    				add(
            	    					current,
            	    					"csv",
            	    					lv_csv_0_0,
            	    					"org.xtext.example.mydsl.MyCsv.CSV");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleCSV"
    // InternalMyCsv.g:100:1: entryRuleCSV returns [EObject current=null] : iv_ruleCSV= ruleCSV EOF ;
    public final EObject entryRuleCSV() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCSV = null;


        try {
            // InternalMyCsv.g:100:44: (iv_ruleCSV= ruleCSV EOF )
            // InternalMyCsv.g:101:2: iv_ruleCSV= ruleCSV EOF
            {
             newCompositeNode(grammarAccess.getCSVRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCSV=ruleCSV();

            state._fsp--;

             current =iv_ruleCSV; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCSV"


    // $ANTLR start "ruleCSV"
    // InternalMyCsv.g:107:1: ruleCSV returns [EObject current=null] : (otherlv_0= 'import' ( (lv_path_1_0= RULE_STRING ) ) otherlv_2= '{' ( (lv_methode_3_0= ruleMethode ) )* otherlv_4= '}' ) ;
    public final EObject ruleCSV() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_path_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_methode_3_0 = null;



        	enterRule();

        try {
            // InternalMyCsv.g:113:2: ( (otherlv_0= 'import' ( (lv_path_1_0= RULE_STRING ) ) otherlv_2= '{' ( (lv_methode_3_0= ruleMethode ) )* otherlv_4= '}' ) )
            // InternalMyCsv.g:114:2: (otherlv_0= 'import' ( (lv_path_1_0= RULE_STRING ) ) otherlv_2= '{' ( (lv_methode_3_0= ruleMethode ) )* otherlv_4= '}' )
            {
            // InternalMyCsv.g:114:2: (otherlv_0= 'import' ( (lv_path_1_0= RULE_STRING ) ) otherlv_2= '{' ( (lv_methode_3_0= ruleMethode ) )* otherlv_4= '}' )
            // InternalMyCsv.g:115:3: otherlv_0= 'import' ( (lv_path_1_0= RULE_STRING ) ) otherlv_2= '{' ( (lv_methode_3_0= ruleMethode ) )* otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,11,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCSVAccess().getImportKeyword_0());
            		
            // InternalMyCsv.g:119:3: ( (lv_path_1_0= RULE_STRING ) )
            // InternalMyCsv.g:120:4: (lv_path_1_0= RULE_STRING )
            {
            // InternalMyCsv.g:120:4: (lv_path_1_0= RULE_STRING )
            // InternalMyCsv.g:121:5: lv_path_1_0= RULE_STRING
            {
            lv_path_1_0=(Token)match(input,RULE_STRING,FOLLOW_5); 

            					newLeafNode(lv_path_1_0, grammarAccess.getCSVAccess().getPathSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCSVRule());
            					}
            					setWithLastConsumed(
            						current,
            						"path",
            						lv_path_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getCSVAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMyCsv.g:141:3: ( (lv_methode_3_0= ruleMethode ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==14||(LA2_0>=16 && LA2_0<=18)) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalMyCsv.g:142:4: (lv_methode_3_0= ruleMethode )
            	    {
            	    // InternalMyCsv.g:142:4: (lv_methode_3_0= ruleMethode )
            	    // InternalMyCsv.g:143:5: lv_methode_3_0= ruleMethode
            	    {

            	    					newCompositeNode(grammarAccess.getCSVAccess().getMethodeMethodeParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_6);
            	    lv_methode_3_0=ruleMethode();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getCSVRule());
            	    					}
            	    					add(
            	    						current,
            	    						"methode",
            	    						lv_methode_3_0,
            	    						"org.xtext.example.mydsl.MyCsv.Methode");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            otherlv_4=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getCSVAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCSV"


    // $ANTLR start "entryRuleMethode"
    // InternalMyCsv.g:168:1: entryRuleMethode returns [EObject current=null] : iv_ruleMethode= ruleMethode EOF ;
    public final EObject entryRuleMethode() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMethode = null;


        try {
            // InternalMyCsv.g:168:48: (iv_ruleMethode= ruleMethode EOF )
            // InternalMyCsv.g:169:2: iv_ruleMethode= ruleMethode EOF
            {
             newCompositeNode(grammarAccess.getMethodeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMethode=ruleMethode();

            state._fsp--;

             current =iv_ruleMethode; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMethode"


    // $ANTLR start "ruleMethode"
    // InternalMyCsv.g:175:1: ruleMethode returns [EObject current=null] : (this_StringParser_0= ruleStringParser | this_PrintCSV_1= rulePrintCSV | this_ReadLine_2= ruleReadLine | this_AddLine_3= ruleAddLine ) ;
    public final EObject ruleMethode() throws RecognitionException {
        EObject current = null;

        EObject this_StringParser_0 = null;

        EObject this_PrintCSV_1 = null;

        EObject this_ReadLine_2 = null;

        EObject this_AddLine_3 = null;



        	enterRule();

        try {
            // InternalMyCsv.g:181:2: ( (this_StringParser_0= ruleStringParser | this_PrintCSV_1= rulePrintCSV | this_ReadLine_2= ruleReadLine | this_AddLine_3= ruleAddLine ) )
            // InternalMyCsv.g:182:2: (this_StringParser_0= ruleStringParser | this_PrintCSV_1= rulePrintCSV | this_ReadLine_2= ruleReadLine | this_AddLine_3= ruleAddLine )
            {
            // InternalMyCsv.g:182:2: (this_StringParser_0= ruleStringParser | this_PrintCSV_1= rulePrintCSV | this_ReadLine_2= ruleReadLine | this_AddLine_3= ruleAddLine )
            int alt3=4;
            switch ( input.LA(1) ) {
            case 14:
                {
                alt3=1;
                }
                break;
            case 16:
                {
                alt3=2;
                }
                break;
            case 17:
                {
                alt3=3;
                }
                break;
            case 18:
                {
                alt3=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalMyCsv.g:183:3: this_StringParser_0= ruleStringParser
                    {

                    			newCompositeNode(grammarAccess.getMethodeAccess().getStringParserParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_StringParser_0=ruleStringParser();

                    state._fsp--;


                    			current = this_StringParser_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMyCsv.g:192:3: this_PrintCSV_1= rulePrintCSV
                    {

                    			newCompositeNode(grammarAccess.getMethodeAccess().getPrintCSVParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_PrintCSV_1=rulePrintCSV();

                    state._fsp--;


                    			current = this_PrintCSV_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalMyCsv.g:201:3: this_ReadLine_2= ruleReadLine
                    {

                    			newCompositeNode(grammarAccess.getMethodeAccess().getReadLineParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_ReadLine_2=ruleReadLine();

                    state._fsp--;


                    			current = this_ReadLine_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalMyCsv.g:210:3: this_AddLine_3= ruleAddLine
                    {

                    			newCompositeNode(grammarAccess.getMethodeAccess().getAddLineParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_AddLine_3=ruleAddLine();

                    state._fsp--;


                    			current = this_AddLine_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMethode"


    // $ANTLR start "entryRuleStringParser"
    // InternalMyCsv.g:222:1: entryRuleStringParser returns [EObject current=null] : iv_ruleStringParser= ruleStringParser EOF ;
    public final EObject entryRuleStringParser() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStringParser = null;


        try {
            // InternalMyCsv.g:222:53: (iv_ruleStringParser= ruleStringParser EOF )
            // InternalMyCsv.g:223:2: iv_ruleStringParser= ruleStringParser EOF
            {
             newCompositeNode(grammarAccess.getStringParserRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStringParser=ruleStringParser();

            state._fsp--;

             current =iv_ruleStringParser; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStringParser"


    // $ANTLR start "ruleStringParser"
    // InternalMyCsv.g:229:1: ruleStringParser returns [EObject current=null] : ( () otherlv_1= 'parseString(' ( (lv_text_2_0= RULE_STRING ) ) otherlv_3= ');' ) ;
    public final EObject ruleStringParser() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_text_2_0=null;
        Token otherlv_3=null;


        	enterRule();

        try {
            // InternalMyCsv.g:235:2: ( ( () otherlv_1= 'parseString(' ( (lv_text_2_0= RULE_STRING ) ) otherlv_3= ');' ) )
            // InternalMyCsv.g:236:2: ( () otherlv_1= 'parseString(' ( (lv_text_2_0= RULE_STRING ) ) otherlv_3= ');' )
            {
            // InternalMyCsv.g:236:2: ( () otherlv_1= 'parseString(' ( (lv_text_2_0= RULE_STRING ) ) otherlv_3= ');' )
            // InternalMyCsv.g:237:3: () otherlv_1= 'parseString(' ( (lv_text_2_0= RULE_STRING ) ) otherlv_3= ');'
            {
            // InternalMyCsv.g:237:3: ()
            // InternalMyCsv.g:238:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getStringParserAccess().getStringParserAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,14,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getStringParserAccess().getParseStringKeyword_1());
            		
            // InternalMyCsv.g:248:3: ( (lv_text_2_0= RULE_STRING ) )
            // InternalMyCsv.g:249:4: (lv_text_2_0= RULE_STRING )
            {
            // InternalMyCsv.g:249:4: (lv_text_2_0= RULE_STRING )
            // InternalMyCsv.g:250:5: lv_text_2_0= RULE_STRING
            {
            lv_text_2_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_text_2_0, grammarAccess.getStringParserAccess().getTextSTRINGTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getStringParserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"text",
            						lv_text_2_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_3=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getStringParserAccess().getRightParenthesisSemicolonKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStringParser"


    // $ANTLR start "entryRulePrintCSV"
    // InternalMyCsv.g:274:1: entryRulePrintCSV returns [EObject current=null] : iv_rulePrintCSV= rulePrintCSV EOF ;
    public final EObject entryRulePrintCSV() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePrintCSV = null;


        try {
            // InternalMyCsv.g:274:49: (iv_rulePrintCSV= rulePrintCSV EOF )
            // InternalMyCsv.g:275:2: iv_rulePrintCSV= rulePrintCSV EOF
            {
             newCompositeNode(grammarAccess.getPrintCSVRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePrintCSV=rulePrintCSV();

            state._fsp--;

             current =iv_rulePrintCSV; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePrintCSV"


    // $ANTLR start "rulePrintCSV"
    // InternalMyCsv.g:281:1: rulePrintCSV returns [EObject current=null] : ( () otherlv_1= 'printCSV();' ) ;
    public final EObject rulePrintCSV() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;


        	enterRule();

        try {
            // InternalMyCsv.g:287:2: ( ( () otherlv_1= 'printCSV();' ) )
            // InternalMyCsv.g:288:2: ( () otherlv_1= 'printCSV();' )
            {
            // InternalMyCsv.g:288:2: ( () otherlv_1= 'printCSV();' )
            // InternalMyCsv.g:289:3: () otherlv_1= 'printCSV();'
            {
            // InternalMyCsv.g:289:3: ()
            // InternalMyCsv.g:290:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getPrintCSVAccess().getPrintAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_1, grammarAccess.getPrintCSVAccess().getPrintCSVKeyword_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePrintCSV"


    // $ANTLR start "entryRuleReadLine"
    // InternalMyCsv.g:304:1: entryRuleReadLine returns [EObject current=null] : iv_ruleReadLine= ruleReadLine EOF ;
    public final EObject entryRuleReadLine() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleReadLine = null;


        try {
            // InternalMyCsv.g:304:49: (iv_ruleReadLine= ruleReadLine EOF )
            // InternalMyCsv.g:305:2: iv_ruleReadLine= ruleReadLine EOF
            {
             newCompositeNode(grammarAccess.getReadLineRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleReadLine=ruleReadLine();

            state._fsp--;

             current =iv_ruleReadLine; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleReadLine"


    // $ANTLR start "ruleReadLine"
    // InternalMyCsv.g:311:1: ruleReadLine returns [EObject current=null] : (otherlv_0= 'readLine(' ( (lv_line_1_0= RULE_INT ) ) otherlv_2= ');' ) ;
    public final EObject ruleReadLine() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_line_1_0=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalMyCsv.g:317:2: ( (otherlv_0= 'readLine(' ( (lv_line_1_0= RULE_INT ) ) otherlv_2= ');' ) )
            // InternalMyCsv.g:318:2: (otherlv_0= 'readLine(' ( (lv_line_1_0= RULE_INT ) ) otherlv_2= ');' )
            {
            // InternalMyCsv.g:318:2: (otherlv_0= 'readLine(' ( (lv_line_1_0= RULE_INT ) ) otherlv_2= ');' )
            // InternalMyCsv.g:319:3: otherlv_0= 'readLine(' ( (lv_line_1_0= RULE_INT ) ) otherlv_2= ');'
            {
            otherlv_0=(Token)match(input,17,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getReadLineAccess().getReadLineKeyword_0());
            		
            // InternalMyCsv.g:323:3: ( (lv_line_1_0= RULE_INT ) )
            // InternalMyCsv.g:324:4: (lv_line_1_0= RULE_INT )
            {
            // InternalMyCsv.g:324:4: (lv_line_1_0= RULE_INT )
            // InternalMyCsv.g:325:5: lv_line_1_0= RULE_INT
            {
            lv_line_1_0=(Token)match(input,RULE_INT,FOLLOW_7); 

            					newLeafNode(lv_line_1_0, grammarAccess.getReadLineAccess().getLineINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getReadLineRule());
            					}
            					setWithLastConsumed(
            						current,
            						"line",
            						lv_line_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getReadLineAccess().getRightParenthesisSemicolonKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleReadLine"


    // $ANTLR start "entryRuleAddLine"
    // InternalMyCsv.g:349:1: entryRuleAddLine returns [EObject current=null] : iv_ruleAddLine= ruleAddLine EOF ;
    public final EObject entryRuleAddLine() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAddLine = null;


        try {
            // InternalMyCsv.g:349:48: (iv_ruleAddLine= ruleAddLine EOF )
            // InternalMyCsv.g:350:2: iv_ruleAddLine= ruleAddLine EOF
            {
             newCompositeNode(grammarAccess.getAddLineRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAddLine=ruleAddLine();

            state._fsp--;

             current =iv_ruleAddLine; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAddLine"


    // $ANTLR start "ruleAddLine"
    // InternalMyCsv.g:356:1: ruleAddLine returns [EObject current=null] : (otherlv_0= 'addLine(' ( (lv_line_1_0= RULE_STRING ) ) otherlv_2= ');' ) ;
    public final EObject ruleAddLine() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_line_1_0=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalMyCsv.g:362:2: ( (otherlv_0= 'addLine(' ( (lv_line_1_0= RULE_STRING ) ) otherlv_2= ');' ) )
            // InternalMyCsv.g:363:2: (otherlv_0= 'addLine(' ( (lv_line_1_0= RULE_STRING ) ) otherlv_2= ');' )
            {
            // InternalMyCsv.g:363:2: (otherlv_0= 'addLine(' ( (lv_line_1_0= RULE_STRING ) ) otherlv_2= ');' )
            // InternalMyCsv.g:364:3: otherlv_0= 'addLine(' ( (lv_line_1_0= RULE_STRING ) ) otherlv_2= ');'
            {
            otherlv_0=(Token)match(input,18,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getAddLineAccess().getAddLineKeyword_0());
            		
            // InternalMyCsv.g:368:3: ( (lv_line_1_0= RULE_STRING ) )
            // InternalMyCsv.g:369:4: (lv_line_1_0= RULE_STRING )
            {
            // InternalMyCsv.g:369:4: (lv_line_1_0= RULE_STRING )
            // InternalMyCsv.g:370:5: lv_line_1_0= RULE_STRING
            {
            lv_line_1_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_line_1_0, grammarAccess.getAddLineAccess().getLineSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAddLineRule());
            					}
            					setWithLastConsumed(
            						current,
            						"line",
            						lv_line_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getAddLineAccess().getRightParenthesisSemicolonKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAddLine"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000076000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000020L});

}